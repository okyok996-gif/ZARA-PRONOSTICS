export default async (request) => {
  const apiKey = process.env.API_FOOTBALL_KEY;
  if (!apiKey) return Response.json({ error: "La variable secrète API_FOOTBALL_KEY n'est pas configurée dans Netlify Functions." }, { status: 500 });
  const url = new URL(request.url);
  const date = url.searchParams.get("date");
  if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) return Response.json({ error: "Date invalide. Format attendu : AAAA-MM-JJ." }, { status: 400 });
  try {
    const upstream = await fetch(`https://v3.football.api-sports.io/fixtures?date=${date}&timezone=Africa%2FAbidjan`, {
      headers: { "x-apisports-key": apiKey, "accept": "application/json" }
    });
    const body = await upstream.json();
    if (!upstream.ok || (body.errors && Object.keys(body.errors).length)) {
      return Response.json({ error: "API-Football a refusé la requête. Vérifie la clé, le forfait ou le quota.", details: body.errors || body.message || upstream.status }, { status: upstream.status || 502 });
    }
    const fixtures = (body.response || []).map(item => ({
      id: item.fixture?.id,
      time: item.fixture?.date ? new Intl.DateTimeFormat("fr-FR", { timeZone: "Africa/Abidjan", hour: "2-digit", minute: "2-digit" }).format(new Date(item.fixture.date)) : null,
      status: item.fixture?.status?.short || "NS",
      league: item.league?.name || "Championnat",
      country: item.league?.country || "",
      home: item.teams?.home?.name || "Équipe domicile",
      away: item.teams?.away?.name || "Équipe extérieur",
      homeGoals: item.goals?.home ?? null,
      awayGoals: item.goals?.away ?? null
    }));
    return Response.json({ date, count: fixtures.length, fixtures, source: "API-Football" }, { headers: { "cache-control": "public, max-age=300" } });
  } catch (error) {
    return Response.json({ error: "Erreur lors de la connexion à API-Football." }, { status: 502 });
  }
};
